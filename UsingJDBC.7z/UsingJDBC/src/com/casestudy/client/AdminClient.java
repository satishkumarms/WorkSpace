package com.casestudy.client;

import com.casestudy.dao.AdminDaol;

public class AdminClient {

	
	public static void main(String[] args)
	{
		AdminDaol admindaol = new AdminDaol();
		if(admindaol.connectToDb())
		{
			System.out.println("connected");
			if(admindaol.validateAdmin())
			{
				
				
				admindaol.addUser();
				admindaol.deleteUser();
				
			}
			else
			{
				System.out.println("Invalid id or password");
			}
		}
		
		
	}
}
