package com.casestudy.client;

import java.sql.SQLException;

import com.casestudy.dao.UserDaol;

public class UserClient {
	
	public static void main(String[] args) throws SQLException
	{
		UserDaol userdaol = new UserDaol();
		if(userdaol.connectToDb())
		{
			System.out.println("connected");
			userdaol.viewBookStore();
			userdaol.addBooksToCart();
			
			/*if(userdaol.validateUser())
			{
			   System.out.println("user login was successful");	
			}
			else
			{
				System.out.println("Invalid userid or password");	

			}*/
		}
	}

}
