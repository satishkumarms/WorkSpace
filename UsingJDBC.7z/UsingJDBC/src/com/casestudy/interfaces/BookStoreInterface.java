package com.casestudy.interfaces;

public interface BookStoreInterface {

	public void viewBookStore();
	public void addBooksToCart();
}
