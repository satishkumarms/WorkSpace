package com.casestudy.interfaces;

public interface UserInterface {
	
	public Boolean validateUser();

}
