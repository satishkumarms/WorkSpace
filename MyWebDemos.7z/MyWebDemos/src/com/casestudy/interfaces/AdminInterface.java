package com.casestudy.interfaces;

public interface AdminInterface {
	
	public Boolean validateAdmin();
	public void addUser();
	public Boolean validateSuperAdmin();

}
